// ave5.h

#define N 5

float h[N]={0.2, 0.2, 0.2, 0.2, 0.2};
