//comb14.h Coefficients file for comb filter with 6 bands

#define	N 14  //number of coefficients h(13),h(12),...,h(0)

float h[N] = {1.0,0,0,0,0,0,0,0,0,0,0,0,0,-1.0};
