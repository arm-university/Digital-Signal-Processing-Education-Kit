// maf5.h
// this file was generated using function tm4c123_fir_coeffs.m
 
#define N 5
 
float32_t h[N] = { 
2.0000E-01,2.0000E-01,2.0000E-01,2.0000E-01,2.0000E-01
};