// maf10.h
// this file was generated using function tm4c123_fir_coeffs.m
 
#define N 10
 
float32_t h[N] = { 
0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1
};